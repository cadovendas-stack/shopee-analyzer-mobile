(function () {
  if (window.__cadoShopeeMobileAnalyzer) return;
  window.__cadoShopeeMobileAnalyzer = true;

  const ITEMS = new Map();
  const STYLE_ID = "cado-mobile-analyzer-style";
  const SHEET_ID = "cado-mobile-analyzer-sheet";
  const STOPWORDS = new Set(["de","da","do","das","dos","e","com","para","por","em","um","uma","kit","novo","nova","original","produto"]);
  const DEFAULTS = { impostoPercent: null, adsPercent: 0, minMonthlySold: 20, maxCompetitors: 15, minRitmo: 1.0, minMargemPercent: 30 };

  function readJson(key, fallback) {
    try { const v = JSON.parse(localStorage.getItem(key)); return v ?? fallback; } catch (_) { return fallback; }
  }
  function writeJson(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {} }
  let fees = { ...DEFAULTS, ...readJson("cado_mobile_fees", {}) };
  let custos = readJson("cado_mobile_costs", {});

  function parseApproxCount(value) {
    if (value === null || value === undefined) return null;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    let s = String(value).toLowerCase().trim().replace(/vendido\(s\)|vendidos?|vendas?/g, "").replace(/\+/g, "").trim();
    if (!s) return null;
    const mult = /(?:mil|k)\b/.test(s) ? 1000 : /(?:mi|mio|milh(?:ão|oes|ões))\b/.test(s) ? 1000000 : 1;
    s = s.replace(/(?:mil|k|mi|mio|milh(?:ão|oes|ões))/g, "").trim();
    // pt-BR: 1,2 -> 1.2; 1.200 -> 1200 when no multiplier.
    if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
    else if (mult === 1 && /^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, "");
    const n = Number(s.replace(/[^0-9.]/g, ""));
    return Number.isFinite(n) ? Math.round(n * mult) : null;
  }

  function parseCapturedItem(raw) {
    if (!raw || typeof raw !== "object") return null;
    const d = raw.item_data && typeof raw.item_data === "object" ? raw.item_data : raw;
    const itemId = d.itemid ?? d.item_id ?? raw.itemid ?? null;
    if (itemId === null || itemId === undefined) return null;
    const priceRaw = d.item_card_display_price?.price ?? d.display_price?.price ?? d.price ?? raw.price ?? null;
    const price = typeof priceRaw === "number" ? priceRaw / 100000 : null;
    const sold = d.item_card_display_sold_count || raw.item_card_display_sold_count || {};
    const monthlyText = sold.monthly_sold_count_text ?? null;
    const historicalText = sold.historical_sold_count_text ?? raw.item_card_displayed_asset?.sold_count?.text ?? raw.sold_count?.text ?? null;
    const monthlySoldApprox = typeof sold.monthly_sold_count === "number" ? sold.monthly_sold_count : parseApproxCount(monthlyText);
    const historicalSold = typeof sold.historical_sold_count === "number" ? sold.historical_sold_count : parseApproxCount(historicalText);
    const ratingStar = typeof d.item_rating?.rating_star === "number" ? d.item_rating.rating_star : null;
    const rc = Array.isArray(d.item_rating?.rating_count) ? d.item_rating.rating_count : null;
    const ratingCount = rc ? rc[0] : null;
    return {
      itemId: Number(itemId),
      name: d.name || raw.item_card_displayed_asset?.name || null,
      price,
      monthlyText,
      monthlySoldApprox,
      historicalText,
      historicalSold,
      ratingStar,
      ratingCount,
      ctime: typeof d.ctime === "number" ? d.ctime : null,
      shopId: d.shopid ?? raw.shopid ?? null,
      isAd: raw.adsid !== undefined && raw.adsid !== null,
      shopLocation: d.shop_data?.shop_location ?? raw.item_card_displayed_asset?.shop_location ?? null
    };
  }

  function mergeItem(item) {
    const previous = ITEMS.get(item.itemId);
    if (!previous) { ITEMS.set(item.itemId, item); return; }
    const merged = { ...previous };
    for (const [k,v] of Object.entries(item)) if (v !== null && v !== undefined && v !== "") merged[k] = v;
    ITEMS.set(item.itemId, merged);
  }

  function classify(json, url) {
    try {
      if (!json || typeof json !== "object") return;
      let list = null;
      if (Array.isArray(json?.data?.units)) list = json.data.units.map(u => u.item || u).filter(Boolean);
      else if (Array.isArray(json?.data?.sections?.[0]?.data?.item)) list = json.data.sections[0].data.item;
      else if (Array.isArray(json?.data?.centralize_item_card?.item_cards)) list = json.data.centralize_item_card.item_cards;
      else if (Array.isArray(json?.items) && json.items.length) list = json.items;
      else if (Array.isArray(json?.data?.items) && json.data.items.length) list = json.data.items;
      if (!list) return;
      let changed = false;
      for (const raw of list) {
        try { const item = parseCapturedItem(raw); if (item) { mergeItem(item); changed = true; } } catch (_) {}
      }
      if (changed) scheduleRender();
    } catch (_) {}
  }

  const originalFetch = window.fetch;
  if (originalFetch) {
    window.fetch = async function (...args) {
      const response = await originalFetch.apply(this, args);
      try {
        const reqUrl = typeof args[0] === "string" ? args[0] : (args[0]?.url || "");
        response.clone().json().then(j => classify(j, reqUrl)).catch(() => {});
      } catch (_) {}
      return response;
    };
  }
  const XHR = window.XMLHttpRequest?.prototype;
  if (XHR) {
    const oo = XHR.open, os = XHR.send;
    XHR.open = function (method, url, ...rest) { this.__cadoUrl = String(url || ""); return oo.apply(this, [method, url, ...rest]); };
    XHR.send = function (...args) {
      this.addEventListener("load", function () { try { classify(JSON.parse(this.responseText), this.__cadoUrl || ""); } catch (_) {} });
      return os.apply(this, args);
    };
  }

  function computeCommission(price) {
    if (!(price >= 0)) return 0;
    if (price <= 79.99) return 4 + price * 0.20;
    if (price <= 99.99) return 16 + price * 0.14;
    if (price <= 199.99) return 20 + price * 0.14;
    return 26 + price * 0.14;
  }
  function ageDays(item) { return item.ctime ? Math.max(1, Math.floor((Date.now() - item.ctime * 1000) / 86400000)) : null; }
  function salesPerDay(item) {
    if (item.monthlySoldApprox === null || item.monthlySoldApprox === undefined) return null;
    const now = new Date(), monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    let activeStart = monthStart;
    if (typeof item.ctime === "number") { const c = new Date(item.ctime * 1000); if (c > activeStart && c <= now) activeStart = c; }
    const a = new Date(activeStart.getFullYear(), activeStart.getMonth(), activeStart.getDate());
    const t = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const days = Math.max(1, Math.floor((t-a)/86400000)+1);
    return item.monthlySoldApprox / days;
  }
  function ritmo(item, daysOld) {
    if (daysOld === null || daysOld < 5 || !(item.historicalSold > 0)) return null;
    const monthly = item.monthlySoldApprox ?? 0;
    if (!(new Date().getDate() >= 5 || monthly >= 10)) return null;
    const curr = salesPerDay(item) || 0, hist = item.historicalSold / daysOld;
    return hist > 0 ? curr / hist : null;
  }
  function margin(item) {
    const cost = Number(custos[String(item.itemId)]);
    if (!Number.isFinite(cost) || !Number.isFinite(fees.impostoPercent) || !Number.isFinite(item.price)) return null;
    const ads = Number.isFinite(fees.adsPercent) ? fees.adsPercent : 0;
    const commission = computeCommission(item.price);
    const value = item.price - commission - item.price*(fees.impostoPercent/100) - item.price*(ads/100) - cost;
    return { value, percent: item.price > 0 ? value/item.price*100 : null, commission };
  }
  function tokens(title) { return String(title||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9 ]/g," ").split(/\s+/).filter(w => w.length>2 && !STOPWORDS.has(w) && isNaN(Number(w))); }
  function similarCount(item) {
    if (!item.name || ITEMS.size < 2) return null;
    const all = [...ITEMS.values()].filter(x=>x.name);
    const freq = new Map();
    for (const x of all) for (const w of new Set(tokens(x.name))) freq.set(w,(freq.get(w)||0)+1);
    const common = new Set([...freq].filter(([,n])=>n/all.length>0.5).map(([w])=>w));
    const a = tokens(item.name).filter(w=>!common.has(w)); if (!a.length) return null;
    let n=0;
    for (const other of all) {
      if (other.itemId===item.itemId) continue;
      const b=tokens(other.name).filter(w=>!common.has(w)); if(!b.length) continue;
      const short=a.length<=b.length?a:b, long=new Set(a.length<=b.length?b:a);
      const shared=short.filter(w=>long.has(w)).length;
      if (shared>=1 && shared/short.length>=0.4) n++;
    }
    return n;
  }
  function score(item) {
    const days=ageDays(item), parts=[];
    const add=(weight,f,ok)=>{ if(ok) parts.push([weight,Math.max(0,Math.min(1,f))]); };
    const m=item.monthlySoldApprox;
    if(typeof m==="number") { const min=20,strong=Math.max(min*5,100); add(25,m<=min?0.5*(m/min):0.5+0.5*((m-min)/(strong-min)),true); }
    const r=ritmo(item,days); if(r!==null) add(15,r<=1?0.5*r:0.5+0.5*((r-1)/0.5),true);
    const c=similarCount(item); if(c!==null) add(20,1-Math.min(c/(15*2),1),true);
    const mg=margin(item); if(mg?.percent!==null) add(25,mg.percent<=0?0:mg.percent<=30?0.6*(mg.percent/30):0.6+0.4*((mg.percent-30)/20),true);
    if(typeof item.ratingStar==="number" || typeof item.ratingCount==="number") {
      let v=0,u=0; if(typeof item.ratingStar==="number"){v+=Math.max(0,Math.min(1,(item.ratingStar-3)/2))*0.7;u+=0.7;} if(typeof item.ratingCount==="number"){v+=Math.max(0,Math.min(1,Math.log10(item.ratingCount+1)/Math.log10(1001)))*0.3;u+=0.3;} add(10,u?v/u:0,true);
    }
    if(days!==null && typeof item.historicalSold==="number") { const rate=item.historicalSold/Math.max(1,days), vel=Math.min(rate/2,1), fresh=days<=60?1:days<=180?0.85:0.7; add(5,vel*0.8+fresh*0.2,true); }
    const w=parts.reduce((s,p)=>s+p[0],0); if(!w) return null;
    const earned=parts.reduce((s,p)=>s+p[0]*p[1],0); return { value:Math.round(earned/w*100), confidence:Math.round(w) };
  }

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s=document.createElement("style"); s.id=STYLE_ID; s.textContent=`
      .cado-metric-chip{display:flex!important;gap:4px;align-items:center;justify-content:center;margin:4px 5px 6px;padding:5px 6px;border-radius:7px;background:#111827;color:#fff;font:700 10px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;box-shadow:0 1px 4px #0003;position:relative;z-index:5}
      .cado-metric-chip b{color:#fde047}.cado-metric-chip .good{color:#86efac}.cado-metric-chip .mid{color:#fde68a}.cado-metric-chip .weak{color:#fca5a5}
      #${SHEET_ID}{position:fixed;z-index:2147483647;left:0;right:0;bottom:0;background:#fff;border-radius:18px 18px 0 0;box-shadow:0 -8px 35px #0005;max-height:78vh;overflow:auto;padding:16px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#111827}
      #${SHEET_ID} .row{display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:13px} #${SHEET_ID} .row strong{text-align:right}
      #${SHEET_ID} input{width:100%;box-sizing:border-box;padding:9px;border:1px solid #cbd5e1;border-radius:8px;font-size:16px;margin-top:4px} #${SHEET_ID} label{font-size:12px;font-weight:700;color:#475569}
      #${SHEET_ID} .grid{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:12px} #${SHEET_ID} button{border:0;border-radius:9px;padding:10px 12px;font-weight:800;font-size:13px} #${SHEET_ID} .primary{background:#ee4d2d;color:white} #${SHEET_ID} .close{background:#f1f5f9;color:#334155;float:right}
      #cado-sheet-backdrop{position:fixed;inset:0;z-index:2147483646;background:#0006}
    `; document.documentElement.appendChild(s);
  }
  function idsFromHref(href) { const m=String(href||"").match(/-i\.(\d+)\.(\d+)/); return m?{shopId:Number(m[1]),itemId:Number(m[2])}:null; }
  function cardFor(anchor) { return anchor.closest('[data-sqe="item"]') || anchor.parentElement?.parentElement || anchor; }
  function fmt(n,d=0){return typeof n==="number"&&Number.isFinite(n)?n.toLocaleString("pt-BR",{minimumFractionDigits:d,maximumFractionDigits:d}):"—";}
  function money(n){return typeof n==="number"&&Number.isFinite(n)?n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"}):"—";}

  function renderCards() {
    ensureStyles();
    document.querySelectorAll('a[href*="-i."]').forEach(a=>{
      const ids=idsFromHref(a.getAttribute("href")); if(!ids) return;
      const item=ITEMS.get(ids.itemId); if(!item) return;
      const card=cardFor(a); if(!card || card.querySelector(`.cado-metric-chip[data-item="${ids.itemId}"]`)) return;
      const sc=score(item), r=ritmo(item,ageDays(item));
      const chip=document.createElement("div"); chip.className="cado-metric-chip"; chip.dataset.item=String(ids.itemId);
      const cls=sc?(sc.value>=80?"good":sc.value>=60?"mid":"weak"):"";
      chip.innerHTML=`<span>📊 <b>${sc?sc.value:"—"}</b>/100</span><span>•</span><span>${fmt(item.monthlySoldApprox)}/mês</span><span>•</span><span class="${cls}">${r!==null?fmt(r,1)+"x":"ritmo —"}</span>`;
      chip.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();openSheet(item.itemId);});
      card.appendChild(chip);
    });
  }
  let timer=null; function scheduleRender(){clearTimeout(timer);timer=setTimeout(renderCards,180);}

  function openSheet(itemId) {
    closeSheet(); const item=ITEMS.get(Number(itemId)); if(!item) return; ensureStyles();
    const bd=document.createElement("div");bd.id="cado-sheet-backdrop";bd.onclick=closeSheet;document.body.appendChild(bd);
    const days=ageDays(item), spd=salesPerDay(item), r=ritmo(item,days), comp=similarCount(item), mg=margin(item), sc=score(item);
    const div=document.createElement("div");div.id=SHEET_ID;
    div.innerHTML=`<button class="close" id="cado-close">Fechar</button><div style="font-size:16px;font-weight:900;padding-right:75px">📊 Análise do anúncio</div><div style="font-size:12px;color:#64748b;margin:7px 0 10px">${escapeHtml(item.name||"Produto")}</div>
      <div class="row"><span>Preço</span><strong>${money(item.price)}</strong></div><div class="row"><span>Vendidos no mês</span><strong>${fmt(item.monthlySoldApprox)}</strong></div><div class="row"><span>Vendas/dia</span><strong>${spd!==null?fmt(spd,1):"—"}</strong></div><div class="row"><span>Vendidos total</span><strong>${fmt(item.historicalSold)}</strong></div><div class="row"><span>Ritmo</span><strong>${r!==null?fmt(r,2)+"x":"—"}</strong></div><div class="row"><span>Concorrentes similares</span><strong>${fmt(comp)}</strong></div><div class="row"><span>Avaliação</span><strong>${item.ratingStar!==null?fmt(item.ratingStar,1)+" ★":"—"} (${fmt(item.ratingCount)})</strong></div><div class="row"><span>Idade</span><strong>${days!==null?days+" dias":"—"}</strong></div>
      <div class="grid"><label>Custo (R$)<input id="cado-cost" inputmode="decimal" value="${custos[String(item.itemId)]??""}"></label><label>Imposto (%)<input id="cado-tax" inputmode="decimal" value="${fees.impostoPercent??""}"></label><label>Ads (%)<input id="cado-ads" inputmode="decimal" value="${fees.adsPercent??0}"></label><div><label>Comissão Shopee</label><div style="padding-top:10px;font-weight:800">${money(mg?.commission ?? computeCommission(item.price))}</div></div></div>
      <button class="primary" id="cado-save" style="width:100%;margin-top:12px">Salvar e recalcular</button>
      <div id="cado-results" style="margin-top:12px">${resultHtml(item)}</div>`;
    document.body.appendChild(div);
    div.querySelector("#cado-close").onclick=closeSheet;
    div.querySelector("#cado-save").onclick=()=>{
      const num=v=>{if(v===null||v===undefined||String(v).trim()==="")return null;const n=Number(String(v).replace(",","."));return Number.isFinite(n)?n:null;};
      const c=num(div.querySelector("#cado-cost").value), t=num(div.querySelector("#cado-tax").value), ads=num(div.querySelector("#cado-ads").value);
      if(c===null) delete custos[String(item.itemId)]; else custos[String(item.itemId)]=c;
      fees.impostoPercent=t; fees.adsPercent=ads??0; writeJson("cado_mobile_costs",custos);writeJson("cado_mobile_fees",fees);
      div.querySelector("#cado-results").innerHTML=resultHtml(item);
      document.querySelectorAll('.cado-metric-chip').forEach(x=>x.remove()); scheduleRender();
    };
  }
  function resultHtml(item){const mg=margin(item), sc=score(item);return `<div style="background:#f8fafc;border-radius:10px;padding:10px"><div style="display:flex;justify-content:space-between;font-weight:900"><span>Margem de contribuição</span><span>${mg?money(mg.value)+" · "+fmt(mg.percent,1)+"%":"informe custo e imposto"}</span></div><div style="display:flex;justify-content:space-between;margin-top:8px;font-weight:900"><span>🎯 Opportunity Score</span><span>${sc?sc.value+"/100":"—"}</span></div><div style="display:flex;justify-content:space-between;margin-top:4px;font-size:12px;color:#64748b"><span>Confiança</span><span>${sc?sc.confidence+"%":"—"}</span></div></div>`;}
  function closeSheet(){document.getElementById(SHEET_ID)?.remove();document.getElementById("cado-sheet-backdrop")?.remove();}
  function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

  ensureStyles();
  new MutationObserver(scheduleRender).observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener("scroll",scheduleRender,{passive:true});
  scheduleRender();
})();
