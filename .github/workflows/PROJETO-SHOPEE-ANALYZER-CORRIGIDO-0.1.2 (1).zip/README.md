# Shopee Analyzer Mobile — MVP 0.1.0

Aplicativo Android experimental para análise de anúncios da Shopee usando a versão web dentro de uma WebView.

## O que faz

- abre `shopee.com.br` dentro do aplicativo;
- intercepta as respostas `fetch`/XHR que a própria Shopee já usa (não cria requisições extras de captura);
- associa os dados aos cards pelos IDs presentes nas URLs dos anúncios;
- mostra um selo compacto em cada card com Opportunity Score, vendidos/mês e Ritmo;
- ao tocar no selo abre um painel inferior com:
  - preço;
  - vendidos no mês;
  - vendas/dia;
  - vendidos totais;
  - Ritmo;
  - concorrentes similares;
  - avaliação e quantidade de avaliações;
  - idade do anúncio;
  - custo;
  - imposto;
  - Ads;
  - comissão Shopee;
  - margem de contribuição;
  - Opportunity Score e confiança.

## Importante

Esta é uma primeira versão experimental. A Shopee pode mudar endpoints, formato dos cards ou comportamento de login na WebView. O aplicativo não modifica o app oficial da Shopee; ele abre a versão web da Shopee dentro do próprio app.

A tabela de comissão foi mantida igual à extensão-base usada neste projeto. Ela deve ser revisada quando a regra comercial da Shopee mudar.

## Abrir no Android Studio

1. Extraia o ZIP.
2. No Android Studio, escolha **Open** e selecione a pasta `ShopeeAnalyzerMobile`.
3. Aguarde a sincronização do Gradle.
4. Execute em um aparelho Android ou emulador com Android 8.0+.

O Android Studio pode sugerir atualizar versões do Gradle/Android Gradle Plugin; isso não altera a lógica do analisador.

## Arquivos principais

- `MainActivity.kt`: configura WebView, cookies, navegação e injeção no início do documento.
- `mobile_analyzer.js`: captura de dados, métricas, badges e painel mobile.

## Segurança

A WebView é limitada a páginas do domínio Shopee. Links externos são abertos no navegador padrão. Custos, imposto e Ads ficam no `localStorage` da própria origem da Shopee dentro do armazenamento da WebView do aplicativo.
